name = 'ltspice'
import ltspice